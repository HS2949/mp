package com.mp_db.miceplan

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}